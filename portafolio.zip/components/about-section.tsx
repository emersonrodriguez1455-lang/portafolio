import content from '@/content/content.json'
import { SectionHeading } from '@/components/section-heading'

/** Sobre mí: perfil, forma de trabajar, experiencia, rumbo y, al final y en pequeño, la formación. */
export function AboutSection() {
  const { about } = content

  return (
    <section id="sobre-mi" aria-labelledby="sobre-mi-titulo" className="grid gap-8 md:grid-cols-[1fr_1.4fr]">
      <SectionHeading id="sobre-mi-titulo" text={about.title} />

      <div className="flex flex-col gap-4 text-base leading-relaxed text-slate md:text-lg">
        {about.paragraphs.map((paragraph) => (
          <p key={paragraph}>{paragraph}</p>
        ))}
        <p className="border-t border-ash pt-4 font-mono text-xs text-smoke">{about.education}</p>
      </div>
    </section>
  )
}
