import { ArrowUpRight, Play } from 'lucide-react'
import { StatusBadge } from '@/components/ui-bits'

export type CaseSection = { title: string; text?: string; list?: string[] }

export type Project = {
  id: string
  image?: { src: string; alt: string }
  title: string
  summary: string
  tags: string[]
  status: string
  video: { show: boolean; src?: string | null; poster?: string | null; description?: string }
  sections: CaseSection[]
  technologies: string[]
  demoUrl: string | null
  siteUrl: string | null
}

/** Tarjeta resumida. Toda la tarjeta es clicable gracias al botón "Ver caso" extendido. */
export function ProjectCard({ project, onOpen }: { project: Project; onOpen: () => void }) {
  return (
    <article className="relative flex w-full flex-col gap-4 group/card rounded-card lg:row-span-6 lg:grid lg:grid-rows-subgrid bg-paper p-6 transition-[transform,box-shadow] duration-200 ease-out hover:-translate-y-1 hover:shadow-[0_12px_32px_-16px_rgb(0_0_0/0.25)] focus-within:-translate-y-1 has-[button:active]:translate-y-0 has-[button:active]:scale-[0.985] has-[button:active]:duration-75">
      {project.image && (
        // Portada 16:10. El recorte vive solo en este contenedor, así el zoom no se sale de la imagen
        <div className="relative aspect-[16/10] overflow-hidden rounded-2xl bg-mist">
          <img
            src={project.image.src}
            alt={project.image.alt}
            width={1280}
            height={800}
            loading="lazy"
            decoding="async"
            className="size-full object-cover object-top transition-transform duration-500 ease-out group-hover/card:scale-[1.04]"
          />
          {project.video.show && project.video.src && (
            <span className="absolute bottom-2 left-2 inline-flex items-center gap-1.5 rounded-pill bg-ink/80 px-2.5 py-1 font-mono text-xs tracking-[-0.03em] text-paper backdrop-blur-sm">
              <Play aria-hidden="true" className="size-[0.875em] fill-current transition-transform duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] group-hover/card:scale-125" />
              Video
            </span>
          )}
        </div>
      )}

      <StatusBadge status={project.status} />

      <h2 className="text-[1.75rem] font-medium leading-[1.1] tracking-[-0.03em] uppercase">{project.title}</h2>
      <p className="text-base text-slate">{project.summary}</p>

      <ul aria-label="Etiquetas" className="mt-auto flex flex-wrap gap-2">
        {project.tags.map((tag) => (
          <li key={tag} className="mint-tag">
            {tag}
          </li>
        ))}
      </ul>

      <button
        type="button"
        onClick={onOpen}
        aria-haspopup="dialog"
        aria-label={`Ver caso: ${project.title}`}
        className="btn-dark self-start justify-self-start after:absolute after:inset-0 after:rounded-card after:content-['']"
      >
        Ver caso
        <ArrowUpRight aria-hidden="true" className="size-[1.125em]" />
      </button>
    </article>
  )
}