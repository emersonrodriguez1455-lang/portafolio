'use client'

import { useEffect, useRef } from 'react'
import { ExternalLink, X } from 'lucide-react'
import type { Project } from '@/components/project-card'
import { Pending, SkillIcon, StatusBadge } from '@/components/ui-bits'
import { Typewriter } from '@/components/typewriter'

/**
 * Caso completo en un <dialog> nativo:
 * - showModal() atrapa el foco y atenúa el fondo.
 * - Esc lo cierra (comportamiento del navegador).
 * - Al cerrar, el navegador devuelve el foco al botón que lo abrió.
 */
export function ProjectDialog({ project, openId }: { project: Project | null; openId: number }) {
  const dialogRef = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const dialog = dialogRef.current
    if (openId && dialog && !dialog.open) dialog.showModal()
  }, [openId])

  const close = () => dialogRef.current?.close()

  return (
    <dialog
      ref={dialogRef}
      onClick={(event) => event.target === event.currentTarget && close()}
      aria-labelledby="caso-titulo"
      className="case-dialog mx-0 mt-auto mb-0 max-h-[92dvh] w-full max-w-none overscroll-contain rounded-t-card rounded-b-none bg-paper p-0 text-ink md:m-auto md:max-h-[calc(100dvh-2rem)] md:w-[calc(100%-2rem)] md:max-w-3xl md:rounded-card"
    >
      {project && (
        <div key={openId} className="case-body flex flex-col gap-6 p-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] md:p-8">
          <span aria-hidden="true" className="mx-auto -mb-3 h-1.5 w-10 shrink-0 rounded-full bg-ash md:hidden" />
          <button
            type="button"
            onClick={close}
            autoFocus
            aria-label="Cerrar caso"
            className="sticky top-0 z-10 ml-auto -mb-4 grid size-10 place-items-center rounded-full bg-ink text-paper transition-transform duration-150 ease-out hover:rotate-90 active:scale-90 active:duration-75"
          >
            <X aria-hidden="true" className="size-[1.25rem]" />
          </button>

          {project.video.show ? (
            <CaseVideo video={project.video} fallbackPoster={project.image?.src} title={project.title} />
          ) : (
            project.image && (
              <img
                src={project.image.src}
                alt={project.image.alt}
                width={1280}
                height={800}
                decoding="async"
                className="aspect-[16/10] w-full rounded-3xl bg-mist object-cover"
              />
            )
          )}

          <div className="flex flex-col items-start gap-3">
            <h2 id="caso-titulo" className="font-display text-4xl leading-[0.9] tracking-[-0.03em] uppercase md:text-5xl">
              <Typewriter text={project.title} start={200} speed={28} />
            </h2>
            <StatusBadge status={project.status} />
          </div>

          {project.sections.map((section) => (
            <section key={section.title} className="flex flex-col gap-2">
              <h3 className="mono-label">{section.title}</h3>
              {section.text && <p className="leading-relaxed text-slate">{section.text}</p>}
              {section.list && (
                <ul className="list-disc space-y-1 pl-5 leading-relaxed text-slate">
                  {section.list.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              )}
            </section>
          ))}

          {project.technologies.length > 0 && (
            <section className="flex flex-col gap-3">
              <h3 className="mono-label">Tecnologías</h3>
              <ul className="flex flex-wrap gap-2">
                {project.technologies.map((tech) => (
                  <li key={tech} className="flex items-center gap-2 rounded-xl bg-mist px-3 py-2 text-sm font-medium">
                    <SkillIcon name={tech} size={20} />
                    {tech}
                  </li>
                ))}
              </ul>
            </section>
          )}

          <div className="flex flex-wrap gap-3 border-t border-ash pt-6">
            {project.siteUrl ? (
              <a href={project.siteUrl} target="_blank" rel="noopener noreferrer" className="btn-dark">
                Ver sitio del equipo
                <ExternalLink aria-hidden="true" size={16} />
              </a>
            ) : project.demoUrl ? (
              <a href={project.demoUrl} target="_blank" rel="noopener noreferrer" className="btn-dark">
                Ver demo
                <ExternalLink aria-hidden="true" size={16} />
              </a>
            ) : (
              <button type="button" disabled className="btn-dark btn-disabled">
                Demo próximamente
              </button>
            )}
            <button type="button" onClick={close} className="btn-ghost">
              Cerrar
            </button>
          </div>
        </div>
      )}
    </dialog>
  )
}

/** Video de recorrido: sin autoplay, con carga diferida. Si aún no hay archivo, muestra un marcador. */
function CaseVideo({ video, title, fallbackPoster }: { video: Project['video']; title: string; fallbackPoster?: string }) {
  return (
    <figure className="flex flex-col gap-2">
      {video.src ? (
        <video
          controls
          playsInline
          preload="none"
          poster={video.poster ?? fallbackPoster}
          className="aspect-video w-full rounded-3xl bg-ink"
          aria-label={`Video de recorrido de ${title}`}
        >
          <source src={video.src} type="video/mp4" />
        </video>
      ) : (
        <div className="grid aspect-video w-full place-items-center rounded-3xl bg-mist">
          <div className="flex flex-col items-center gap-2 text-center">
            <span className="font-display text-3xl uppercase md:text-5xl">Video próximamente</span>
            <Pending label="archivo de video" />
          </div>
        </div>
      )}
      {video.description && <figcaption className="text-sm text-slate">{video.description}</figcaption>}
    </figure>
  )
}
