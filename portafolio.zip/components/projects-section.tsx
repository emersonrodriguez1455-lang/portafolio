'use client'

import { useState } from 'react'
import content from '@/content/content.json'
import { ProjectCard, type Project } from '@/components/project-card'
import { ProjectDialog } from '@/components/project-dialog'
import { Typewriter } from '@/components/typewriter'
import { Reveal } from '@/components/reveal'

/** Titular + tres tarjetas en la primera pantalla. Al abrir una, se muestra el caso completo. */
export function ProjectsSection() {
  const projects = content.projects as Project[]
  const { hero } = content
  // El proyecto se conserva al cerrar para que la animación de salida muestre el contenido.
  const [selection, setSelection] = useState<{ project: Project; openId: number } | null>(null)

  return (
    <section id="proyectos" aria-label="Presentación y proyectos" className="flex flex-col gap-6 pt-4 md:gap-8 md:pt-8">
      <div className="hero-glow flex flex-col gap-4">
        <p className="mono-label">
          <Typewriter text={hero.greeting} start={150} speed={30} />
        </p>

        <h1 className="font-display text-5xl leading-[0.9] tracking-[-0.03em] uppercase md:text-7xl lg:text-[5.5rem]">
          <Typewriter text={hero.title} start={950} speed={45} caret />
        </h1>

        <div className="rise flex flex-col gap-4 lg:flex-row lg:items-center lg:gap-8" style={{ '--d': '1850ms' } as React.CSSProperties}>
          <ul aria-label="Enfoque" className="flex shrink-0 flex-wrap gap-2">
            {hero.focus.map((item, i) => (
              <li
                key={item}
                className={
                  i === hero.focus.length - 1
                    ? 'rounded-pill bg-ink px-3 py-1 font-mono text-xs tracking-[-0.03em] text-paper md:px-4 md:py-1.5 md:text-sm'
                    : 'rounded-pill bg-mint px-3 py-1 font-mono text-xs tracking-[-0.03em] md:px-4 md:py-1.5 md:text-sm'
                }
              >
                {item}
              </li>
            ))}
          </ul>
          <p className="max-w-2xl text-sm leading-relaxed md:text-base text-slate text-pretty">{hero.summary}</p>
        </div>
      </div>

      {/* En tablet (2 columnas) la última tarjeta impar ocupa toda la fila para no dejar un hueco */}
      <Reveal
        as="ul"
        variant="list"
        firstDelay={900}
        className="grid gap-3 md:grid-cols-2 md:gap-4 md:max-lg:[&>li:last-child:nth-child(odd)]:col-span-2 lg:grid-cols-3 lg:gap-5"
      >
        {projects.map((project) => (
          // Subgrid en escritorio: portada, estado, título, resumen, etiquetas y botón quedan alineados entre las tres tarjetas
          <li key={project.id} className="flex lg:row-span-6 lg:grid lg:grid-rows-subgrid lg:gap-y-4">
            <ProjectCard project={project} onOpen={() => setSelection({ project, openId: Date.now() })} />
          </li>
        ))}
      </Reveal>

      <ProjectDialog project={selection?.project ?? null} openId={selection?.openId ?? 0} />
    </section>
  )
}