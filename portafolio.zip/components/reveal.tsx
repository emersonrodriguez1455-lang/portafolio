'use client'

import { useEffect, useRef, type ComponentPropsWithoutRef, type CSSProperties } from 'react'

type RevealProps = {
  /** "section": se escalonan los hijos de la <section> envuelta. "list": se escalonan los hijos directos. */
  variant?: 'section' | 'list'
  as?: 'div' | 'ul'
  /** Retraso solo para la primera aparición (p. ej. esperar a que termine la máquina de escribir del hero). */
  firstDelay?: number
} & ComponentPropsWithoutRef<'div'>

/**
 * Hace aparecer sus bloques en cascada cada vez que entran en pantalla, al bajar y al subir.
 * Se ocultan de nuevo solo cuando salen por completo, así nunca desaparecen a la vista.
 * Animación en CSS (`[data-reveal]` en globals.css); aquí solo se cambia un atributo.
 */
export function Reveal({ variant = 'section', as: Tag = 'div', firstDelay = 0, style, ...rest }: RevealProps) {
  const ref = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    // Entra cuando asoma un 12% por encima del borde inferior: el movimiento ocurre donde se mira.
    const enter = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) el.dataset.in = ''
      },
      { rootMargin: '0px 0px -12% 0px' },
    )
    const leave = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting || !('in' in el.dataset)) return
      delete el.dataset.in
      el.style.setProperty('--reveal-base', '0ms')
    })

    enter.observe(el)
    leave.observe(el)
    return () => {
      enter.disconnect()
      leave.disconnect()
    }
  }, [])

  return (
    <Tag
      // @ts-expect-error: el ref es válido para cualquiera de los dos elementos permitidos
      ref={ref}
      data-reveal={variant}
      style={{ '--reveal-base': `${firstDelay}ms`, ...style } as CSSProperties}
      {...rest}
    />
  )
}
